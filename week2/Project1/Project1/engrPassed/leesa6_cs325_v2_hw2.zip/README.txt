It contains the information on how to compolile the files.
I used c++ programming language for the HW 1.

if you type "make" on the command line, all file will compiled. However, if it doesn't work 
please follow another instruction below. Thank you.

Question 5.a
Please make sure you have the data.txt on the same directory. 
[If "make" doesn't complie, then compile the codes by typing g++ -o badTest badsort_fa.cpp]
and simply run the program ./badTest

Once you run the program, it will ask you to enter the alpha value.
first = numerator
and second = denominator

Then, you should enter the integer vlaue that represent an alpha value. For example,
if you want to choose the 2/3 for your alpha value, then enter 1


Question 5.b
I am used the chrono library to compute time execution time. 
[If "make" doesn't complie, then compile the codes by typing g++ -std=c++11 -o badTtest modified_badsort.cpp]

After complete the compile, simply run the program by typing ./badTtest