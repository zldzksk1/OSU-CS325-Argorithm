/******************************************************************************************************
 * Name: Pamela Yin
 * Class: CS 325 Section 401
 * Date: July 26, 2020
 * Description: HW4 Question 5: In this program we read input from files that contain number of players,
 * 				names, and number of rivalries, and rivalries listed in pairs. Topologial sort is used
 * 				to sort the members into team "Beavers" and "Ducks". If it is possible to divide members
 * 				into two teams, output each team members, if not display not possible.
 ******************************************************************************************************/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <unordered_map>

using namespace std;

void splitTeams(vector<string> players, vector<string> rivals1, vector<string> rivals2) {
	bool possible = true;

	//assign all vertices to unassigned
	unordered_map<string, string> team;
	for (unsigned int i = 0; i < players.size(); i++) {
		team.insert({players[i], "unassigned"});
	}
	
	//go through each vertex, find if there's an edge that needs to be checked 
	for (unsigned int i = 0; i < team.size(); i++) {
		auto it1 = team.find(players[i]);
		vector<string>::iterator itr1 = find(rivals1.begin(), rivals1.end(), it1->first);
		
		//find all edges that are connected from the vertex
		while (itr1 != rivals1.cend()) {
			int index1 = distance(rivals1.begin(), itr1);
			//find the vertex where the edge is connected to
			auto it2 = team.find(rivals2[index1]);

			//if both vertex unassigned (non-colored vertex)
			if (it1->second == "unassigned" && it2->second == "unassigned") {
				it1->second = "Beaver";
				it2->second = "Duck";
			//if one is unassigned and one is beaver, assign unassigned to duck
			} else if (it1->second == "unassigned" && it2->second == "Beaver") {
				it1->second = "Duck";
			} else if (it1->second == "Beaver" && it2->second == "unassigned") {
				it2->second = "Duck";
			//if one is unassigned and one is duck, assign unassigned to beaver
			} else if (it1->second == "unassigned" && it2->second == "Duck") {
				it1->second = "Beaver";
			} else if (it1->second == "Duck" && it2->second == "unassigned") {
				it2->second = "Beaver";
			//if both are assigned the same color (aka team) then return false, teams not possible
			} else if (it1->second == it2->second) {
				possible = false;
				break;
			} 
			//find another edge that is connected to from the vertex 	
			itr1 = find(rivals1.begin() + index1 + 1, rivals1.end(), it1->first);
		}
	}

	//if possible, print out team members, if not print not possible
	if (possible) {
		cout << "Yes" << endl;
		unordered_map<string, string>:: iterator p; 
		//beavers
		cout << "Beavers: ";
		for (p = team.begin(); p != team.end(); p++) {
			if (p->second == "Beaver") {
				cout << p->first << " ";
			} 
		}
		cout << endl;
		//ducks
		cout << "Ducks: ";
		for (p = team.begin(); p != team.end(); p++) {
			if (p->second == "Duck") {
				cout << p->first << " ";
			} 
		}
		cout << endl;
	} else {
		cout << "Not Possible" << endl;
	}
	
}

int main() {
	string filename;
	cout << "Which file would you like to open?" << endl;
	cin >> filename;
	//open file
	ifstream infile(filename);
	if (infile.is_open()) {
		string str;
		int playerCount = 0, rivalCount = 0;
		vector<string> players;
		vector<string> rivals1;
		vector<string> rivals2;
		
		while (!infile.eof()) {
			//read in player (vertex) count
			getline(infile,str);
			stringstream ss(str);
			string playerStr;
			ss >> playerStr;
			playerCount = stoi(playerStr);

			//read in player names 
			int i = 0;
			while (i++ < playerCount) {
				getline(infile,str);
				istringstream ss(str);
				string player = str;
				ss >> player;
				players.push_back(player);
			}

			//read in rival counts
			getline(infile, str);
			string rivalStr = str;
			rivalCount = stoi(rivalStr);

			//save rivalries as edges (vector pairs)
			while (getline(infile, str)) {
				istringstream ss(str);
				string rival1, rival2;
				ss >> rival1 >> rival2;
				rivals1.push_back(rival1);
				rivals2.push_back(rival2);	
			}
		}
		
		//print input to console
		cout << "-----Input Summary-----" << endl;
		cout << "Player Count: " << playerCount << endl;
		for (unsigned int k = 0; k < players.size(); k++) {
			cout << "Player " << k+1 << ": " << players[k] << endl;
		}
		cout << endl;
		cout << "Rival Count: " << rivalCount << endl;
		for (unsigned int l = 0; l < rivals1.size(); l++) {
			cout << rivals1[l] << " - " << rivals2[l] << endl;
		}
		cout << "-----------------------" << endl;
		infile.close();	

		cout << "\n\n--------------Results--------------\n" << endl;

		//check if teams can be formed
		splitTeams(players, rivals1, rivals2);

	} else {
		cout << "File not found" << endl;
	}

	return 0;
}