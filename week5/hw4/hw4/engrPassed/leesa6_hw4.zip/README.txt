//I included the makefile, so you can simple enter 'make', it will creat executable programs for the
question 5.c

-----5.c-----

Please make sure you have the correct txt file on the same directory.
and also make sure it has only appropriate text inputs.
Text file should not have extra comments, sample output, extra linebreak.

if make commend didn't work
please enter g++ -std=c++1y -o teamCheck main3.cpp dfsColor2.cpp dfsColor2.hpp
and simply run the program teamCheck. By typing ./teamCheck

if you run the program, it will prompt the output based on the txt file.
