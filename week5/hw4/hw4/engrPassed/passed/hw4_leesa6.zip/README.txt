//I included the makefile, so you can simple enter 'make', it will creat executable programs for the
question 5.c

-----5.c-----

Please make sure you have the correct txt file on the same directory.
and also make sure it has only appropriate text inputs.
Text file should not have extra comments, sample output, extra linebreak.

if make commend didn't work
please enter g++ -std=c++1y -o teamCheck main.cpp dfsColor.cpp dfsColor.hpp
and simply run the program teamCheck by typing ./teamCheck

if you run the program, it will ask you enter the file name. When you give a file name do not include
extention of the file. For example, if you want to enter "beaverducks.txt", then just enter "beaverducks".
Then it will return the result.


