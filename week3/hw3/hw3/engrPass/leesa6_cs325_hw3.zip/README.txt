//I included the makefile, so you can simple enter 'make', it will creat executable programs for the
question 4, and the extra question

-----Question 4d------

Please make sure you have the data.txt on the same directory.

if make commend didn't work
please enter g++ -std=c++11 -o knapsackTest knapsack.cpp
and simply run the program ./knapsackTest

if you run the program, it will ask you enter capacity which is Weight of knapsack.
Please enter Natural number only.

It will prompt the optimal value and the optimal subset

-----Question Extra-----

Please make sure you have the data.txt on the same directory.

if make commend didn't work
please enter g++ -std=c++11 -o knapsackAllTest knapsack_extra_done.cpp
and simply run the program ./knapsackAllTest

if you run the program, it will ask you enter capacity which is Weight of knapsack.
Please enter Natural number only.

It will prompt the optimal value and all the optimal subsets
